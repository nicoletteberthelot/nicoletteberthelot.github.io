var total = 0;
$("#out").val("outputButton")
$("#out").css("outputColor")


// +10

$("#a10").click(addTen)
function addTen() {
	total = total + 10;

	var outputButton = $("#out").html(total)
}

$("#a20").click(addTwenty)
function addTwenty() {
	total = total + 20;

	var outputButton = $("#out").html(total)
}

$("#a30").click(addThirty)
function addThirty() {
	total = total + 30;

	var outputButton = $("#out").html(total)
}

$("#n10").click(minusTen)
function minusTen() {
	total = total - 10;

	var outputButton = $("#out").html(total)
}

$("#n20").click(minusTwenty)
function minusTwenty() {
	total = total - 20;

	var outputButton = $("#out").html(total)
}

$("#n30").click(minusThirty)
function minusThirty() {
	total = total - 30;

	var outputButton = $("#out").html(total)
}

$("#blue").click(changeBlue)
function changeBlue() {
	var outputColor = $("#out").css("background-color", "blue")
}


$("#red").click(changeRed)
function changeRed() {
	var outputColor = $("#out").css("background-color", "red")
}

$("#out").click(reset)
function reset() {
	var outputColor = $("#out").css("background-color", "white")
	var outputButton = $("#out").html("0")
}
// +20

// var plusTwenty = document.querySelector("#a20");

// plusTwenty.onclick = addTwenty;

// function addTwenty() {
// 	total = total + 20;

// 	document.querySelector("#out").innerHTML = total;
// }

// // +30

// var plusThirtyButton = document.querySelector("#a30");

// plusThirtyButton.onclick = addThirty;

// function addThirty() {
// 	total = total + 30;

// 	document.querySelector("#out").innerHTML = total;
// }

// // -10

// var minusTenButton = document.querySelector("#n10");

// minusTenButton.onclick = subtractTen;

// function subtractTen() {
// 	total = total - 10;

// 	document.querySelector("#out").innerHTML = total;
// }


// // -20

// var minusTwentyButton = document.querySelector("#n20");

// minusTwentyButton.onclick = subtractTwenty;

// function subtractTwenty() {
// 	total = total - 20;

// 	document.querySelector("#out").innerHTML = total;
// }

// // -30

// var minusThirtyButton = document.querySelector("#n30");

// minusThirtyButton.onclick = subtractThirty;

// function subtractThirty() {
// 	total = total - 30;

// 	document.querySelector("#out").innerHTML = total;
// }

// // red

// var redButton = document.querySelector("#red");

// redButton.onclick = turnRed;

// function turnRed() {
// 	document.querySelector("#out").style.background = "red";
// }

// // blue

// var blueButton = document.querySelector("#blue");

// blueButton.onclick = turnBlue;

// function turnBlue() {
// 	document.querySelector("#out").style.background = "blue";
// }

// // reset

// var outputButton = document.querySelector("#out");

// outputButton.onclick = reset;

// function reset() {
// 	total = 0;

// 	document.querySelector("#out").innerHTML = total;
// 	document.querySelector("#out").style.background = "white";
// }
