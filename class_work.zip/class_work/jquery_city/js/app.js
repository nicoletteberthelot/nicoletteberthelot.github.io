// 1. Create .click() handlers for each of the thumbnails: #first, #second, #third, #fourth
// 2. Use .attr() to change the `src` attribute of #bigimage to correspond to image that was clicked

$(".thumb").click(changeImage);

function changeImage(event) {
	var newSrc = $(event.currentTarget).attr("src");
	$("#bigimage").attr("src", newSrc)
}



// $('#first').click(swapImages1)
// $('#second').click(swapImages2)
// $('#third').click(swapImages3)
// $('#fourth').click(swapImages4)


// function swapImages1() {
// $("#bigimage").attr("src", "img/1.jpg");
// }

// function swapImages2() {
// $("#bigimage").attr("src", "img/2.jpg");
// }

// function swapImages3() {
// $("#bigimage").attr("src", "img/3.jpg");
// }
// function swapImages4() {
// $("#bigimage").attr("src", "img/4.jpg");
// }