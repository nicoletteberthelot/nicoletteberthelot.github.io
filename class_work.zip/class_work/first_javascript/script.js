function hello() {
alert("hello")
}
hello()
var title = document.querySelector ("#title")
console.log(title)

