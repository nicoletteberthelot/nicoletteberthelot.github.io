
$(".row").click(showWrapper)

function showWrapper(event) {
$(event.currentTarget).find(".wrapper").slideToggle(300);
}
