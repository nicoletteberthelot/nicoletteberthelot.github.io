// As a user
// When I enter a number into the input and submit
// I expect the new entry to appear in the table

var total = 0;

$("#entry").submit(changeAmt);

function changeAmt(event) {
	event.preventDefault();
	var newEntry = $("#newEntry").val()
	$("#entries").append("<tr>" + "<td>" + newEntry + "</tr>" + "</td>")
	// console.log(newEntry)

	var newEntryNumber = document.querySelector ('#total').innerHTML;

	var newEntryNumber = parseInt(newEntry)

	var newEntryNumber = (total + newEntry)

	document.querySelector ('#total').innerHTML = newEntryNumber;

	console.log(newEntryNumber)
	}

	// var out = document.querySelector ('#out').innerHTML;

	// out = parseInt(out);

	// var sum = (out + 20);

	// document.querySelector ('#out').innerHTML = sum;

// $("#clickme").click(function() {
// 	var text = $("#item").val()
// 	var output = "<ul>" + text + "</ul";

// 	$("#list").append(output);

// 	$("#item").val("");
// })
	

// As a user
// When I enter a number into the input and submit
// I expect the total to be updated as the sum all of the entries

// As a user
// When I enter a number into the input and submit
// I expect the input to be cleared

// look into ParseInt



// $("#append").click(function () {
//   var text = $("#text").val();
//   var output = "<p>" + text + "</p>";
  
//   $("#target").append(output);
  
//   $("#text").val("");
// })