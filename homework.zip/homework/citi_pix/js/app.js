// As a user
// When I change my selection
// I expect the background image to change into the image of my selection

$("#city-type").change(changeCity);

function changeCity() {
var userSelection = $("#city-type").val();

$(userSelection).toggleClass('.nyc .sf .la .atx .syd'); 


// $(".container").toggleclass("#city-type");

console.log(userSelection)


}

// .nyc {
//   background-image: url(../images/nyc.jpg)
// }
// .sf {
//   background-image: url(../images/sf.jpg)
// }
// .la {
//   background-image: url(../images/la.jpg)
// }
// .atx {
//   background-image: url(../images/austin.jpg)
// }
// .syd {
//   background-image: url(../images/sydney.jpg)


// $("body").onclick(changeToBlue);
// function changeToBlue() {
// $(".container").toggleClass("blue");
// }